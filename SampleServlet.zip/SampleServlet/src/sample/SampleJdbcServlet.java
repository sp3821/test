package sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
/**
 * Servlet implementation class SampleJdbcServlet
 */
@WebServlet("/SampleJdbcServlet")
public class SampleJdbcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SampleJdbcServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public void doGet(HttpServletRequest req,HttpServletResponse res)
    	    throws ServletException, IOException
    	  {
    	    String datasource = "java:comp/env/jdbc/TeradataDS";
    	    res.setContentType("text/html");
    	    PrintWriter out = res.getWriter();
    	    out.println("<html><body><pre>");
    	    try
    	    {
    	      Context ctx = new InitialContext();

    	      out.println("Looking up datasource " + datasource);
    	      DataSource ds = (DataSource) ctx.lookup(datasource);

    	      out.println("Establishing connection...");

    	      Connection con = ds.getConnection();
    	      out.println("Connection obtained is: " + con);

    	      con.close();
    	      out.println("Connection.isClosed returns: " + con.isClosed());
    	    }
    	    catch (SQLException ex)
    	    {
    	      out.println("*** SQLException caught ***");
    	      while (ex != null)
    	      {
    	        out.println("Message: " + ex.getMessage ());
    	        out.println("SQLState: " + ex.getSQLState ());
    	        out.println("ErrorCode: " + ex.getErrorCode ());
    	        ex.printStackTrace (out);
    	        ex = ex.getNextException ();
    	      }
    	    }
    	    catch (java.lang.Exception ex)
    	    {
    	      out.println("*** Exception caught ***");
    	      ex.printStackTrace (out);
    	    }

    	    out.println("SampleJdbcServlet finished.");
    	    out.println("</pre></body></html>");
    	    out.close();
    	  }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
