param (
    [string]$encodedFilePath,
    [string]$fastloadPath
)

$Secure2 = Get-Content $encodedFilePath | ConvertTo-SecureString -Key (1..16)
$plainTextPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure2))
#$plainTextPassword | Set-Content $fastloadPath
#��ȡ�ļ�����
$FileContent = Get-Content -Path $fastloadPath
#�滻����
$UpdatedContent = $FileContent -replace "password", $plainTextPassword
$UpdatedContent  | Set-Content fastload2.in




