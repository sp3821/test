<?
phpinfo();
22243
